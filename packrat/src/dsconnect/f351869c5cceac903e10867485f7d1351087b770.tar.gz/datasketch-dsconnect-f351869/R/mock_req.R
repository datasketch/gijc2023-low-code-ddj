
mock_req <- function(...){
  args <- list(...)
  req <- list()
  l <- args
  if(!is.null(l$file)){
    l$file <- httr::upload_file(args$file)
  }
  l
}
