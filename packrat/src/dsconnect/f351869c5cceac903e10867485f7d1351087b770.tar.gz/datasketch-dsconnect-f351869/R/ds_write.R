
#' Upload a Dataframe to Datasketch Cloud
#'
#' This function allows users to upload a dataframe to the Datasketch Cloud platform.
#' It requires authentication and interacts with Datasketch's REST API.
#'
#' @param x Dataframe you want to upload.
#' @param dspath Path on Datasketch Cloud where the dataframe should be uploaded.
#' @param username (Optional) Datasketch username. Defaults to `DS_AUTH_USERNAME` from the environment variables.
#' @param token (Optional) Authentication token for Datasketch Cloud. Defaults to `DS_AUTH_TOKEN` from the environment variables.
#' @param org (Optional) Organization on Datasketch Cloud. Defaults to the provided username.
#' @param ... Additional arguments passed to the `object_write_rds` function.
#'
#' @return A message indicating the URL where the dataframe has been uploaded.
#' @export
#'
#' @examples
#' \dontrun{
#' df <- data.frame(a = 1:5, b = 6:10)
#' ds_write(df, "username/path-to-database")
#' }
ds_write <- function(x, dspath, username = NULL, token = NULL, org = NULL,
                     ...){

  resource_info <- dsconnect::validate_resource(dspath, username, token)
  slug <- resource_info$resource

  username <- username %||% Sys.getenv("DS_AUTH_USERNAME") %||% resource_info$username
  token <- token %||% Sys.getenv("DS_AUTH_TOKEN")
  org <- org %||% username

  if(!auth(username, token)){
    stop("Unauthorized")
  }else{
    message("user '", username, "' correctly logged in.")
  }



  # Write RDS
  #info <- object_write_rds(x)
  info <- object_write_rds(x, ...)

  file <- info$filename
  org <- username
  body <- mock_req(file = file, username = username,
                   token = token, org = org,
                   slug = slug)
  res <- httr::POST("https://services.datasketch.co/upload_rds/upload_rds",
                    body = body)
  result <- httr::content(res)

  if(!is.null(result$error)){
    stop(result$error)
  }

  url <- "https://datasketch.co"
  r <- file.path(url, "org",result[[1]]$username,"dbs", result[[1]]$resource_slug)
  message("Uploaded to: ", r)
}





