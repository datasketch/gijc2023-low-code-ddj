
#' @export
validate_resource <- function(dspath, username, token){
  path <- strsplit(dspath,"/")[[1]]
  username <- path[1]
  resource <- path[2]
  subresource <- path[3]
  list(
    username = username,
    resource = resource,
    subresource = subresource)

}



