
#' @export
object_type <- function(x){

  if(inherits_any(x, c("data.frame", "hdtable")))
    return("table")
  if(inherits_any(x, c("hdbase")))
    return("base")
  if(inherits_any(x, c("list"))){
   if(unique(purrr::map_chr(x, class)) == "data.frame")
     return("base")
  }
  if(inherits_any(x, c("ggplot", "htmlwidgets", "hdviz")))
    return("viz")
}
