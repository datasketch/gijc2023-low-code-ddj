
#' @export
ds_read <- function(slug, username = NULL, token = NULL,
                    type = NULL){


  res <- validate_resource(slug, username, token)

  type <- res$type
  username <- res$username
  resource <- res$resource
  subresource <- res$subresource

  ds_read_table(username, resource, subresource)

}



#'
ds_read_table <- function(username, resource, subresource = NA){

  s3url <- "https://s3.amazonaws.com/uploads.dskt.ch"
  metajson <- "{s3url}/{username}/{resource}/{resource}.base.json"
  metajson <- glue::glue(metajson)

  if(is.na(subresource)){
    meta <- jsonlite::read_json(metajson)
    subresource <- meta$hdtables_slugs[1]
  }
  path <-  glue::glue("{s3url}/{username}/{resource}/{subresource}.csv")
  d <- readr::read_csv(path, show_col_types = FALSE)
  d
}

