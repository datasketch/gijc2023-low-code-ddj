
#' @export
auth <- function(username = NULL, token = NULL, org = NULL){
  username <- username %||% Sys.getenv("DS_AUTH_USERNAME")
  token <- token %||% Sys.getenv("DS_AUTH_TOKEN")
  org <- org %||% username
  url <- "https://services.datasketch.co/auth"
  res <- httr::GET(paste0(url,"/auth"),
                   query = list(username = username,
                                token = token))
  httr::content(res)
}

