
#' @export
object_write_rds <- function(object, filename = NULL, ...){

  args <- list(...)
  meta <- args[!names(args) %in% c("name", "description")]
  type <- object_type(object)
  l <- list(
    object = object,
    type = type,
    name = args$name,
    description = args$description,
    meta = meta
  )
  filename <- filename %||% tempfile(fileext = ".rds")
  #if(dstools::file_ext(filename) != "gz") stop("file extension must be .rds.gz")
  #readr::write_rds(l, file = filename, compress = "gz")
  readr::write_rds(l, file = filename)
  list(
    filename = filename,
    type = type,
    name = args$name,
    description = args$description,
    meta = meta
  )
}
