test_that("ds_write", {


  x <- iris
  username <- Sys.getenv("DS_AUTH_USERNAME")
  token <- Sys.getenv("DS_AUTH_TOKEN")

  dspath <- paste0(username, "/iris-3453")

  ds_write(x, dspath)

  dspath <- "jpmarindiaz/iris-122111111"
  ds_write(x, dspath)


  dspath <- "jpmarindiaz/testtest"
  ds_write(x, dspath)

})
