test_that("multiplication works", {


  username <- Sys.getenv("DS_AUTH_USERNAME")
  token <- Sys.getenv("DS_AUTH_TOKEN")

  expect_true(auth(username, token))

  username <- "xxx"
  token <- "xxx"
  expect_false(auth(username, token))

})
